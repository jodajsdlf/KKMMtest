package egov.cmm;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.HashMap;
import java.util.Map;

import java.text.DecimalFormat;

public class Utils {
	// 객체 -> map
	public static Map<String, Object> convertObjectToMap(Object obj) throws IllegalAccessException {
		Map<String, Object> map = new HashMap<>();
		Class<?> clazz = obj.getClass();
		for (Field field : clazz.getDeclaredFields()) {
			field.setAccessible(true);
			map.put(field.getName(), field.get(obj));
		}
		return map;
	}

	// 천단위 콤마 ( 10000 -> 10,000)
	// 사용: String num = Utils.numberFormat(Long.parseLong("100000"));
	public static <T> String numberFormat(T number) {
		DecimalFormat formatter = new DecimalFormat("#,###");
		return formatter.format(number);
	}

	// 숫자를 한글로 변경
	// 사용: String num = Utils.numberToKorean(Long.parseLong("100000"));
	public static String numberToKorean(long number) {
		if (number == 0)
			return "영";

		final String[] UNIT2 = { "", "만", "억", "조", "경", "해", "자", "양", "구", "간" };
		String result = "";
		int unitIndex = 0; // 만, 억, 조 등의 단위 인덱스

		while (number > 0) {
			int group = (int) (number % 10000); // 숫자를 4자리씩 그룹으로 나누기
			result = convertGroupToKorean(group) + UNIT2[unitIndex] + result;
			number /= 10000;
			unitIndex++;
		}
		return result;
	}

	private static String convertGroupToKorean(int number) {
		final String[] HANGUL_NUMERALS = { "", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구" };
		final String[] UNIT1 = { "", "십", "백", "천" };
		String result = "";
		int digitIndex = 0;

		while (number > 0) {
			int digit = number % 10;
			if (digit != 0) {
				result = HANGUL_NUMERALS[digit] + UNIT1[digitIndex] + result;
			}
			number /= 10;
			digitIndex++;
		}
		return result;
	}

	//CSV생성
	public static StringBuilder backup(String tableName) {
		// Oracle JDBC 연결 정보 설정
		String url = "jdbc:oracle:thin:@192.168.219.106:1521:xe";
		String username = "kkm";
		String password = "12345";
		// String tableName = "boards";

		try {
			// Oracle 데이터베이스에 연결
			Connection connection = DriverManager.getConnection(url, username, password);

			// SELECT 쿼리 실행
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + tableName);
			ResultSet resultSet = statement.executeQuery();
			ResultSetMetaData metaData = resultSet.getMetaData();

			StringBuilder insertStatement = new StringBuilder("");

			// CSV 헤더 생성
			insertStatement.append(tableName + "\n");
			for (int i = 1; i <= metaData.getColumnCount(); i++) {
				insertStatement.append(metaData.getColumnName(i));
				if (i < metaData.getColumnCount()) {
					insertStatement.append(",");
				}
			}
			insertStatement.append("\n");

			// CSV 본문 생성
			while (resultSet.next()) {
				for (int i = 1; i <= metaData.getColumnCount(); i++) {
					insertStatement.append("\"").append(resultSet.getString(i)).append("\"");
					if (i < metaData.getColumnCount()) {
						insertStatement.append(", ");
					}
				}
				insertStatement.append("\n");
			}

			//Insert문 생성
//          while (resultSet.next()) {
//              insertStatement.append("INSERT INTO " + tableName + " VALUES (");              
//              for (int i = 1; i <= metaData.getColumnCount(); i++) {
//                  insertStatement.append("'").append(resultSet.getString(i)).append("'");
//                  if (i < metaData.getColumnCount()) {
//                      insertStatement.append(", ");
//                  }
//              }
//              insertStatement.append(");\n");
//          }

			//System.out.println("Backup completed successfully.");

			// 리소스 해제
			resultSet.close();
			statement.close();
			connection.close();

			return insertStatement;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
