package egov.cmm;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
public class SessionController {

    @GetMapping("/extend-session.do")
    public ResponseEntity<String> extendSession(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        
        if (session != null) {// 세션을 연장합니다.            
            session.setMaxInactiveInterval(15 * 60); // (단위: 초) 기본설정 web.xml
            return ResponseEntity.ok("세션 연장 성공");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("세션이 만료되었습니다");
        }
    }
}
