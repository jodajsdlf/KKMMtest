package egov.cmm;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WildcardMessageSource extends ReloadableResourceBundleMessageSource {
    private final ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();

    @Override
    public void setBasenames(String... basenames) {
        List<String> resolvedBasenames = new ArrayList<>();
        
        for (String basename : basenames) {
            try {
                // 와일드카드 패턴을 사용하여 리소스 로드
                Resource[] resources = resourcePatternResolver.getResources(basename);
                
                // 로드된 리소스에서 베이스 이름 추출
                for (Resource resource : resources) {
                    String uri = resource.getURI().toString();
                    
                    // 리소스 URI에서 베이스 이름 추출
                    String baseName = uri.substring(uri.indexOf("/message/"));
                    baseName = baseName.substring(0, baseName.lastIndexOf("."));
                    System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
                    System.out.println(baseName);
                    // 중복 제거 및 리스트에 추가
                    if (!resolvedBasenames.contains("classpath:"+baseName)) {
                        resolvedBasenames.add("classpath:"+baseName);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        
        // 부모 클래스의 setBasenames 메서드 호출
        super.setBasenames(resolvedBasenames.toArray(new String[0]));
    }
}
