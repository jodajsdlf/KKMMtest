package egov.cmm.error;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public class Errors {
	
	public static String loginError(Model model) {		
		String err = (String) model.getAttribute("error");
		
		if ("validEmpty".equals(err)) {
			model.addAttribute("error", new ErrorVO("loginPage.do","로그인 오류 발생.","정보를 정확히 입력해 주세요."));
		} else if ("validEngNum".equals(err)) {
			model.addAttribute("error", new ErrorVO("loginPage.do","로그인 오류 발생.","영문/숫자만 입력해 주세요."));
		} else {
			model.addAttribute("error", new ErrorVO("loginPage.do","로그인 오류 발생","ID/PW를 적확히 입력해 주세요."));
		}		
		
		return "error";
	}
	
	public static String boardInsertError(Model model) {
		String err = (String) model.getAttribute("error");
		
		if ("validEmpty".equals(err)) {
			model.addAttribute("error", new ErrorVO("write.do","입력 오류발생.","제목/내용을 입력해 주세요."));
		} else if ("dbError".equals(err)) {
			model.addAttribute("error", new ErrorVO("write.do","입력 오류발생.","DB에 입력중 오류 발생."));
		} else{
			model.addAttribute("error", new ErrorVO("write.do","입력 오류발생","알수 없는 이유로 등록하지 못함."));
		}
		
		return "error";
	}
	
	public static String backupError(Model model) {
		String err = (String) model.getAttribute("error");
		
		if ("listCSV".equals(err)) {
			model.addAttribute("error", new ErrorVO("board.do"," 오류발생.","목록 조회중 오류가 발생하였습니다.."));
		} else if ("backupCSV".equals(err)) {
			model.addAttribute("error", new ErrorVO("backup.do"," 오류발생.","백업파일 생성중 오류가 발생하였습니다."));
		} else if ("delFile".equals(err)) {
			model.addAttribute("error", new ErrorVO("backup.do"," 오류발생","백업파일 삭제중 오류가 발생하였습니다."));
		} else{
			model.addAttribute("error", new ErrorVO("backup.do"," 오류발생"," 오류가 발생하였습니다."));
		}
		
		return "error";
	}
	
	public static String boardViewError(Model model) {
		//String err = (String) model.getAttribute("error");

		model.addAttribute("error", new ErrorVO("board.do","조회 오류발생","글 조회중 오류가 발생하였습니다."));

		return "error";
	}

	public static String boardDelError(Model model) {
		model.addAttribute("error", new ErrorVO("board.do","삭제 오류발생","글 삭제중 오류가 발생하였습니다."));
		return null;
	}


}
