package egov.cmm.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Aspect
@Component
//@PropertySource("classpath:application.properties")
public class myAspect {

	@AfterThrowing
    public void handleException(Exception ex) {
        System.out.println(":예외 발생: " + ex.getMessage());
    }
    
    @After("execution(* egov..impl.*Impl.*(..))")
    public void afterAdvice(JoinPoint jp) {
        System.out.println(jp.getTarget().getClass().getSimpleName() +" : " + jp.getSignature().getName() + " 실행 후 실행되는 Advice입니다.");
    }
    
    @Before("execution(* egov..impl.*Impl.*(..))")
    public void beforeAdvice(JoinPoint jp) {
   	 System.out.println(jp.getTarget().getClass().getSimpleName() +" : " + jp.getSignature().getName() + " 실행 전 실행되는 Advice입니다.");
    }
    
/*
@AfterThrowing: Advice를 지정한 메서드를 대상 메서드가 예외를 던진 후에 실행하도록 지정하는 어노테이션입니다. 대상 메서드가 예외를 던질 때 Advice 메서드가 실행됩니다.
@After: Advice를 지정한 메서드를 대상 메서드가 실행된 후(정상적으로 반환되었든 예외가 발생했든 상관없이) 실행하도록 지정하는 어노테이션입니다.
@Before: Advice를 지정한 메서드를 대상 메서드가 실행되기 전에 실행하도록 지정하는 어노테이션입니다. 대상 메서드 실행 전에 Advice 메서드가 실행됩니다.
@AfterReturning: Advice를 지정한 메서드를 대상 메서드가 반환된 후에 실행하도록 지정하는 어노테이션입니다. 대상 메서드가 예외를 던지지 않고 정상적으로 반환될 때 Advice 메서드가 실행됩니다.
@Around: Advice를 지정한 메서드를 대상 메서드를 감싸서 전후에 실행하도록 지정하는 어노테이션입니다. 대상 메서드 실행 전후에 사용자가 원하는 작업을 수행할 수 있습니다.
@Aspect: Aspect 클래스를 정의할 때 사용하는 어노테이션입니다. Aspect는 특정 Join Point에서 Advice를 실행하는 클래스입니다.
@Pointcut: 특정 Join Point를 지정하는 어노테이션입니다. 여러 Advice에서 공통으로 사용되는 포인트컷을 정의할 수 있습니다.
*/
}