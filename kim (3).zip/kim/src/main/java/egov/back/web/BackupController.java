package egov.back.web;

import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import egov.back.model.FileVO;
import egov.back.service.BackupService;
import egov.back.service.impl.CustomTaskScheduler;
import egov.cmm.error.Errors;


@Controller
public class BackupController {
	
	@Resource
	BackupService backupService; 
	
	@Autowired
   private LocaleResolver localeResolver;
	
	@Autowired
	CustomTaskScheduler customTaskScheduler;
	
	@RequestMapping("/backupCSV.do")
	public String backupCSV(Model model) throws Exception{
		try {
		backupService.backupCSV();
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.backupError(model);
		} 
		return "redirect:backup.do?msg=save";
	}
	
	@RequestMapping("/backup.do")
	public String backup(HttpServletRequest request, Model model) throws Exception{
		Locale currentLocale = localeResolver.resolveLocale(request);
		System.out.println(currentLocale.toString());
		try {
			List<FileVO> fileList = backupService.listCSV();
			model.addAttribute("fileList", fileList);
			model.addAttribute("states", customTaskScheduler.getState());
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.backupError(model);
		} 
		return "backup/backup";
	}
	
	@RequestMapping("/schedule.do")
	public String schedule() {
		String msg;
		if(customTaskScheduler.getState() == 0) {
			msg="schon";
			customTaskScheduler.startScheduler();
		}else{
			msg="schoff";
			customTaskScheduler.stopScheduler();
		}
		return "redirect:backup.do?msg="+msg;
	}
	
	@RequestMapping("/download.do")
   public ResponseEntity<byte[]> downloadFile(HttpServletRequest request, HttpServletResponse response) {
   	try {
   		return backupService.download(request);
		} catch (Exception e) {
			 e.printStackTrace(); // 오류 발생 시 클라이언트에게 오류 상태와 메시지를 반환할 수 있도록 처리	       
	       String errorMessage = "파일 다운로드 중 오류가 발생했습니다.";
	       return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorMessage.getBytes());
		}
   }
   
   // 파일 삭제
	@RequestMapping(value = "delete.do")
	public String delFile(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		try {
			backupService.delFile(request);
		} catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.backupError(model);
		}      
		return "redirect:backup.do?msg=delete";
	}


}
