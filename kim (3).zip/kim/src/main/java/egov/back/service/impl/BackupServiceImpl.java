package egov.back.service.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;

import egov.back.model.FileVO;
import egov.back.service.BackupService;
import egov.board.service.impl.BoardServiceImpl;
import java.io.File;
import java.io.FileWriter;

@Service
public class BackupServiceImpl extends EgovAbstractServiceImpl implements BackupService {

	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);
	
	@Value("${csv.backup.directory}")
	private String directory;

	@Resource
	private BackupMapper backupDAO;
	

	
	//백업파일 생성
	@Override
	public void backupCSV() throws Exception {
		logger.info("################################### backupCSV ###################################");
		BackupThread backupThread = new BackupThread(backupDAO, directory);
		backupThread.start();
//		try {
//			Date currentDate = new Date();
//			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
//			String fileName = dateFormat.format(currentDate) + ".csv";
//
//			List<String> rows = backupDAO.selectTable();
//			// System.out.println(rows);
//
//			FileWriter fileWriter = new FileWriter(directory + fileName);
//			PrintWriter printWriter = new PrintWriter(fileWriter);
//
//			for (String row : rows) {
//				// StringBuilder insertStatement = Utils.backup(row);//다른 DB백업 방법.
//				StringBuilder insertStatement = dbToCSV(row); //테이블별 백업문자열 요청
//				printWriter.println(insertStatement.toString());
//			}
//
//			printWriter.close();
//			fileWriter.close();
//		} catch (Exception e) {
//			throw new Exception("backupCSV");
//		}
	}

	
	
	//테이블별 백업문장열 생성 메서드
	private StringBuilder dbToCSV(String tableName) throws Exception {
		List<Map<String, Object>> tableData = backupDAO.selectAll(tableName);
		StringBuilder insertStatement = new StringBuilder("");
		// CSV 헤더 생성
		insertStatement.append(tableName + "\n");
		if (tableData.size() > 0) {
			for (String key : tableData.get(0).keySet()) {
				insertStatement.append(key).append(",");
			}
			insertStatement.deleteCharAt(insertStatement.length() - 1); // 마지막 쉼표 제거
			insertStatement.append("\n");

			// CSV 데이터 작성
			for (Map<String, Object> lines : tableData) {
				for (Object value : lines.values()) {
					insertStatement.append(value).append(",");
				}
				insertStatement.deleteCharAt(insertStatement.length() - 1); // 마지막 쉼표 제거
				insertStatement.append("\n");
			}
		}else {
			insertStatement.append("내용이 없습니다.\n");			
		}
		Thread.sleep(100);
		return insertStatement;
	}


	
	//csv파일 목록 반환
	@Override
	public List<FileVO> listCSV() throws Exception {
		List<FileVO> fileList = new ArrayList<>();
		try {
			File folder = new File(directory);
			if (folder.exists() && folder.isDirectory()) {
				File[] files = folder.listFiles();
				for (File file : files) {
					FileVO fileVO = new FileVO(file.getName(), Long.toString(Math.round((double) file.length() / 1024))+"KB");
					fileList.add(fileVO);
				}
			}
		} catch (Exception e) {
			throw new Exception("listCSV");
		}
		//Thread.sleep(100);
		return fileList;
	}

	
	//파일 다운로드
	@Override
	public ResponseEntity<byte[]> download(HttpServletRequest request) throws Exception {
		String fileName = request.getParameter("fileName");		
		String filePath = directory + fileName;

		try {
			Path file = Paths.get(filePath);
			byte[] data = Files.readAllBytes(file);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			headers.setContentDispositionFormData("attachment", fileName);
			headers.setContentLength(data.length);
			return new ResponseEntity<>(data, headers, HttpStatus.OK);
		} catch (IOException ex) {
			throw new RuntimeException("File not found or cannot be read: " + filePath, ex);
		}

	}

	//파일 삭제
	@Override
	public void delFile(HttpServletRequest request) throws Exception {
		try {
			String fileName = request.getParameter("fileName");
			String filePath = directory + fileName;
			File file = new File(filePath);
			if (file.delete()) {
				System.out.println("파일 삭제성공!");
			}
		} catch (Exception e) {
			throw new Exception("delFile");
		}

	}

}
