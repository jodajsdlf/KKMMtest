package egov.back.service.impl;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;





public class BackupThread extends Thread {
	
	private String directory;
	
	private BackupMapper backupDAO;
	


	
	public BackupThread(BackupMapper backupDAO, String directory) {

		this.backupDAO = backupDAO;
		this.directory= directory;
	}
	
	public void run() {
		try {
			Date currentDate = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
			String fileName = dateFormat.format(currentDate) + ".csv";

			List<String> rows = backupDAO.selectTable();
			// System.out.println(rows);

			FileWriter fileWriter = new FileWriter(directory + fileName);
			PrintWriter printWriter = new PrintWriter(fileWriter);

			for (String row : rows) {
				// StringBuilder insertStatement = Utils.backup(row);//다른 DB백업 방법.
				//System.out.println(row);
				StringBuilder insertStatement = dbToCSV(row); //테이블별 백업문자열 요청
				printWriter.println(insertStatement.toString());
				//Thread.sleep(50);
			}

			printWriter.close();
			fileWriter.close();
			

		} catch (Exception e) {
			//throw new Exception("backupCSV");
			System.out.println(e);
		}
  }
	
	//테이블별 백업문장열 생성 메서드
	private StringBuilder dbToCSV(String tableName) throws Exception {
		List<Map<String, Object>> tableData = backupDAO.selectAll(tableName);
		StringBuilder insertStatement = new StringBuilder("");
		// CSV 헤더 생성
		insertStatement.append(tableName + "\n");
		if (tableData.size() > 0) {
			for (String key : tableData.get(0).keySet()) {
				insertStatement.append(key).append(",");
			}
			insertStatement.deleteCharAt(insertStatement.length() - 1); // 마지막 쉼표 제거
			insertStatement.append("\n");

			// CSV 데이터 작성
			for (Map<String, Object> lines : tableData) {
				for (Object value : lines.values()) {
					insertStatement.append(value).append(",");
				}
				insertStatement.deleteCharAt(insertStatement.length() - 1); // 마지막 쉼표 제거
				insertStatement.append("\n");
			}
		}else {
			insertStatement.append("내용이 없습니다.\n");			
		}
		Thread.sleep(100);
		return insertStatement;
	}

}
