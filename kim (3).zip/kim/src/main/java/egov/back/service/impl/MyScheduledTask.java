//package egov.back.service.impl;
//
//import javax.annotation.Resource;
//
//
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import egov.back.service.BackupService;
//
//@Component
//@EnableScheduling
//public class MyScheduledTask {
//
//	@Resource
//	BackupService backupService;
//
//	@Scheduled(cron = "0 * * * * ?") // cron 표현식
//	public void performTask() {
//		try {
//			backupService.backupCSV();
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//		System.out.println("+++++++++++++++Scheduled task executed.+++++++++++++++++++");
//	}
//	
//	
//
//}


//=======cron 표현식 예시=====
//0 0 0 * * ?: 매일 자정에 실행합니다.
//0 0 12 * * ?: 매일 정오(12시)에 실행합니다.
//0 0 0 ? * MON: 매주 월요일 자정에 실행합니다.
//0 0 8 * * MON-FRI: 평일 오전 8시에 실행합니다.
//0 0/5 * * * ?:  매 5분마다 실행합니다.

//초(Seconds): 0-59
//분(Minutes): 0-59
//시(Hours): 0-23
//일(Day of month): 1-31
//월(Month): 1-12 or JAN-DEC
//요일(Day of week): 0-6 or SUN-SAT (0은 일요일)
//년도(Year) (선택사항): 예: 2022