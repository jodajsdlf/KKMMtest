//package egov.back.service.impl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import org.springframework.batch.core.Job;
//import org.springframework.batch.core.JobParameters;
//import org.springframework.batch.core.Step;
//import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
//import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
//import org.springframework.batch.core.launch.JobLauncher;
//import org.springframework.batch.core.step.tasklet.Tasklet;
//import org.springframework.batch.repeat.RepeatStatus;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.scheduling.annotation.Scheduled;
//
//
//@Configuration
//@EnableBatchProcessing
//public class BatchScheduleTask {
//	
//   @Autowired
//   private JobBuilderFactory jobBuilderFactory;
//
//   @Autowired
//   private StepBuilderFactory stepBuilderFactory;
//
//   @Autowired
//   private JobLauncher jobLauncher;
//
//
//   
//   public Job myJob() {
//   	 System.out.println("-----------myJob----------------");
//        return jobBuilderFactory.get("myJob")
//                .start(myStep())
//                .build();
//    }
//   
//
//   public Step myStep() {
//   	System.out.println("-----------myStep----------------");
//   	return stepBuilderFactory.get("myStep")
//   			.tasklet(simpleTasklet())
//   			.build();
//   }
//   
//
//   public Tasklet simpleTasklet() {
//     	System.out.println("-----------simpleTasklet----------------");
//       return (stepContribution, chunkContext) -> {
//           for (int i = 10; i > 0; i--) {
//               System.out.println(i);
//           }
//           return RepeatStatus.FINISHED;
//       };
//   }
//
//   @Scheduled(cron = "0/10 * * * * ?") // 매 분마다 실행
//   public void executeBatchJob() throws Exception {
//   	System.out.println("-----------@Scheduled----------------");
//      jobLauncher.run(myJob(), new JobParameters());
//   }
//   
//}