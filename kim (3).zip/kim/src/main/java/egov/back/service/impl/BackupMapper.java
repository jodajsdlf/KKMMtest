package egov.back.service.impl;

import java.util.List;
import java.util.Map;

import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

@Mapper
public interface BackupMapper {
	List<Map<String, Object>> selectAll(String tableName) throws Exception;
	List<String> selectTable() throws Exception;
}
