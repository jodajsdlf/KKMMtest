package egov.back.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import egov.back.service.BackupService;
import lombok.Data;

import javax.annotation.PreDestroy;


@Data
@Component
@EnableScheduling
public class CustomTaskScheduler {

   private int state = 0;

   private ThreadPoolTaskScheduler taskScheduler;

   @Autowired
   private BackupService backupService;
   
   public CustomTaskScheduler() {
   	this.taskScheduler = new ThreadPoolTaskScheduler();
   }

   public void startScheduler() {
       // 스케줄러 시작
       state = 1;
       taskScheduler.initialize();
       taskScheduler.schedule(() -> {
           try {
               backupService.backupCSV();
           } catch (Exception e) {
               System.out.println(e.getMessage());
           }
           System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Scheduled task executed.%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
       }, new CronTrigger("0/30 * * * * ?")); // cron 표현식
   }

   @PreDestroy
   public void stopScheduler() {
       // 스케줄러 종료
       state = 0;
       taskScheduler.destroy();
   }
}

//=======cron 표현식 예시=====
//0 0 0 * * ?: 매일 자정에 실행합니다.
//0 0 12 * * ?: 매일 정오(12시)에 실행합니다.
//0 0 0 ? * MON: 매주 월요일 자정에 실행합니다.
//0 0 8 * * MON-FRI: 평일 오전 8시에 실행합니다.
//0 0/5 * * * ?:  매 5분마다 실행합니다.

//초(Seconds): 0-59
//분(Minutes): 0-59
//시(Hours): 0-23
//일(Day of month): 1-31
//월(Month): 1-12 or JAN-DEC
//요일(Day of week): 0-6 or SUN-SAT (0은 일요일)
//년도(Year) (선택사항): 예: 2022