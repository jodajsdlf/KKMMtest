package egov.back.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import egov.back.model.FileVO;

public interface BackupService {
	public void backupCSV() throws Exception;

	public List<FileVO> listCSV() throws Exception;

	public ResponseEntity<byte[]> download(HttpServletRequest request) throws Exception;

	public void delFile(HttpServletRequest request) throws Exception;


}
