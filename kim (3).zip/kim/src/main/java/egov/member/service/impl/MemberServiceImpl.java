package egov.member.service.impl;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import egov.cmm.ValidationForm;
import egov.member.model.LoginVO;
import egov.member.model.MemberVO;
import egov.member.service.MemberService;

@Service
public class MemberServiceImpl  extends EgovAbstractServiceImpl implements MemberService {
	
	private static final Logger logger = LoggerFactory.getLogger(ValidationForm.class);
	
	@Resource
	MemberMapper memberDAO; 

	@Override
	public MemberVO login(HttpSession session,LoginVO loginVO) throws Exception {
		logger.info("################################### login ###################################");
		
		if(ValidationForm.validEmpty(loginVO.getMemberId()) || ValidationForm.validEmpty(loginVO.getMemberPw())) { throw new Exception("validEmpty"); }
		if(!ValidationForm.validEngNum(loginVO.getMemberId()) || !ValidationForm.validEngNum(loginVO.getMemberPw())) { throw new Exception("validEngNum"); }
		
		MemberVO memberVO = memberDAO.login(loginVO);
		if(memberVO == null) { throw new Exception("loginError"); }
		
		session.setAttribute("loginInfo", memberVO);
		
		return memberVO ;
	}

}
