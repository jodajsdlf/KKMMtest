package egov.member.service;

import javax.servlet.http.HttpSession;

import egov.member.model.LoginVO;
import egov.member.model.MemberVO;

public interface MemberService {
	MemberVO login(HttpSession session, LoginVO loginVO)throws Exception;
}
