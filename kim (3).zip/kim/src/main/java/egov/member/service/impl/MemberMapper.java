package egov.member.service.impl;

import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import egov.member.model.LoginVO;
import egov.member.model.MemberVO;

@Mapper
public interface MemberMapper {
	MemberVO login(LoginVO LoginVO)throws Exception;
}
