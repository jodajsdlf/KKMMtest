package egov.member.model;

import lombok.Data;

@Data
public class LoginVO {
	private String memberId;
	private String memberPw;
}
