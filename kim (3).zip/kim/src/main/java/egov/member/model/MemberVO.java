package egov.member.model;

import lombok.Data;

@Data
public class MemberVO {
	private String memberId;
	private String memberName;

}
