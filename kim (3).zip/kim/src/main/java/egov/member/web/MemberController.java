package egov.member.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egov.cmm.ValidationForm;
import egov.cmm.error.Errors;
import egov.member.model.LoginVO;
import egov.member.service.MemberService;

@Controller
public class MemberController {
	
	private static final Logger logger = LoggerFactory.getLogger(ValidationForm.class);
	
	@Autowired
	MemberService memberService; 
	
	@RequestMapping("loginPage.do")
	public String loginPage() {
		return "member/login";
	}
	
	@RequestMapping("login.do")
	public String login(LoginVO loginVO,HttpServletRequest request, Model model ) throws Exception{
		logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ /login.do @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");	
		HttpSession session = request.getSession();
		try {
			memberService.login(session, loginVO);
		}catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.loginError(model);
		}
		Thread.sleep(100);
		return "redirect:board.do";
	}
	
	@RequestMapping("/logout.do")
	public String logout(HttpServletRequest request,@RequestParam(value = "msg", required = false, defaultValue = "") String msg) throws Exception {
		HttpSession session = request.getSession();
		session.invalidate();
		if(msg.isEmpty()) {msg="logout";}

		return "redirect:loginPage.do?msg="+msg;
	}

}
