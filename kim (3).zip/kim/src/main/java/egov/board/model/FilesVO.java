package egov.board.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class FilesVO {
	private String fileGroudId;
	private String saveName;
	private String originalName;
	private String fileSize;

}
