package egov.board.model;

import lombok.Data;
import java.util.Date;

import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.web.multipart.MultipartFile;

@Data
public class BoardVO {
	private int  boardId;
	private Date writeTime;
	private String title;
	private String boardContents; 
	private int groupId=0;
	private int depth=10;
	private String sort="";
	private int out_parm;
	private int hit=0;
	private int likes=0;
	private int bads=0;
	private int likeState=0;
	private String memberId;
	private String fileGroudId;
	MultipartFile[] files;
	
	public String day() {
		 FastDateFormat dateFormat = FastDateFormat.getInstance("yyyy-MM-dd EEE");
       String formattedDate = dateFormat.format(this.writeTime);
       return formattedDate;
	}
}
