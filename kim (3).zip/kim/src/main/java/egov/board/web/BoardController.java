package egov.board.web;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.jms.Session;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import egov.board.model.BoardVO;
import egov.board.model.FilesVO;
import egov.board.service.BoardService;
import egov.cmm.ValidationForm;
import egov.cmm.error.Errors;
import egov.cmm.page.Paging;
import egov.cmm.page.Search;
import egov.member.model.MemberVO;
import org.springframework.web.servlet.LocaleResolver;
@Controller
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	BoardService boardService;
	
	@Autowired
   private LocaleResolver localeResolver;
	
	@RequestMapping("/board.do")
	public String board(HttpServletRequest request, Search sch, @RequestParam(name="num", required = false)Integer num, Model model) throws Exception{
		logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ /board.do @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");	
		HttpSession session = request.getSession();
		int sessionTimeout = session.getMaxInactiveInterval();
      System.out.println(">>>>>>sestime:"+sessionTimeout);
      
		Locale currentLocale = localeResolver.resolveLocale(request);
		//logger.error("");
		System.out.println(currentLocale.toString());
			
      MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
      System.out.println(loginInfo);
		
		try {
			int totalCnt = boardService.selectBoardListTotCnt();
			List<BoardVO> boardList = boardService.selectBoardList(sch);
			
			model.addAttribute("paging", new Paging(sch, totalCnt)); 
			model.addAttribute("boardList", boardList);
			model.addAttribute("cnt", totalCnt);
		}catch (Exception e) {
			System.out.println(e);
		}
		//Thread.sleep(500);
		return "board/board";
	}
	
	@RequestMapping("/list.do")
	public String list(HttpServletRequest request, Search sch, @RequestParam(name="num", required = false)Integer num, Model model) throws Exception{
		logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ /board.do @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");		
		//logger.error("");
		HttpSession session = request.getSession();
      MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
      System.out.println(loginInfo);
		
		try {
			int totalCnt = boardService.selectBoardListTotCnt();
			List<BoardVO> boardList = boardService.selectBoardList(sch);
			
			model.addAttribute("paging", new Paging(sch, totalCnt)); 
			model.addAttribute("boardList", boardList);
			model.addAttribute("cnt", totalCnt);
		}catch (Exception e) {
			System.out.println(e);
		}
		//Thread.sleep(500);
		return "board/list";
	}
	
	@RequestMapping("/write.do")
	public String write() {
		return "board/write";
	}
	
	@RequestMapping("view.do")
	public String view(HttpServletRequest request,BoardVO boardVO, Search sch, Model model) throws Exception{
		HttpSession session = request.getSession();
      MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
      boardVO.setMemberId(loginInfo.getMemberId());
		Locale currentLocale = localeResolver.resolveLocale(request);
		System.out.println(currentLocale.toString());
		try {
			BoardVO boardView = boardService.viewBoard(boardVO);
			if(boardView.getFileGroudId() != null) {
				List<FilesVO> fileList = boardService.viewFileList(boardView.getFileGroudId());
				model.addAttribute("fileList",fileList);
			}
			model.addAttribute("boardView",boardView);
			model.addAttribute("sch",sch);
		}catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.boardViewError(model);
		}
		return "board/view";
	}
	
	@RequestMapping("/boardLike.do")
   public ResponseEntity<?> boardLike(HttpServletRequest request,BoardVO boardVO) throws Exception{
   	HttpSession session = request.getSession();
      MemberVO loginInfo = (MemberVO)session.getAttribute("loginInfo");
      boardVO.setMemberId(loginInfo.getMemberId());
   	boardService.likeBoard(boardVO);
   	BoardVO boardView = boardService.viewBoard(boardVO);
      return ResponseEntity.ok(boardView);
   }
	
	@RequestMapping("reply.do")
	public String reply(HttpServletRequest request,BoardVO boardVO, Model model) throws Exception{
		BoardVO boardView = boardService.viewBoard(boardVO);
		System.out.println(boardView.getDepth());
		model.addAttribute("boardView",boardView);
		return "board/reply";
	}

	@RequestMapping("del.do")
	public String del(BoardVO boardVO, Search sch, Model model) throws Exception{
		try {
			boardService.delBoard(boardVO);

		}catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.boardDelError(model);
		}
		return "redirect:board.do?pageNum=" + sch.getPageNum() +"&msg=delete";
	}
	
	
	@RequestMapping("/filedown.do")
   public ResponseEntity<byte[]> fileDown(HttpServletRequest request, HttpServletResponse response)  throws Exception{
   	try {
   		return boardService.download(request);
		} catch (Exception e) {
			throw new Exception("fileError");
		}
		
   }
	
	@RequestMapping("/insert.do")
	public String insert(BoardVO boardVO, Model model) throws Exception{
		logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ /insert.do @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");	
		
		try {
			boardService.insertBoard(boardVO);
		}catch (Exception e) {
			model.addAttribute("error", e.getMessage());			 
			return Errors.boardInsertError(model);
		}
	 
		return "redirect:board.do?msg=save";
	}

}
