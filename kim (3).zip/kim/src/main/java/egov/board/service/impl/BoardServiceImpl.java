package egov.board.service.impl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import egov.board.model.FilesVO;
import egov.board.model.BoardVO;
import egov.board.service.BoardService;
import egov.cmm.ValidationForm;
import egov.cmm.page.Search;

@Service
//@PropertySource("classpath:application.properties")
public class BoardServiceImpl extends EgovAbstractServiceImpl implements BoardService {

	private static final Logger logger = LoggerFactory.getLogger(BoardServiceImpl.class);

	@Value("${board.upload.directory}")
	private String directory;

	@Resource
	private BoardMapper boardDAO;

	@Override
	public List<BoardVO> selectBoardList(Search sch) throws Exception {
		logger.info("################################### selectBoardList ###################################");
		return boardDAO.selectBoardList(sch);
	}

	@Override
	public int selectBoardListTotCnt() throws Exception {
		return boardDAO.selectBoardListTotCnt();
	}

	@Override
	public void insertBoard(BoardVO boardVO) throws Exception {
		logger.info("################################### insertBoard ###################################");
		// logger.info(boardVO.getTitle());
		// logger.error(Utils.numberFormat(Long.parseLong(boardVO.getTitle())));
		// logger.error(Utils.numberToKorean(Long.parseLong(boardVO.getTitle())));

		if (ValidationForm.validEmpty(boardVO.getTitle()) || ValidationForm.validEmpty(boardVO.getBoardContents()))
			throw new Exception("validEmpty");

		String fileGroudId = fileUpload(boardVO.getFiles());

		boardVO.setFileGroudId(fileGroudId);
		boardDAO.insertBoard(boardVO);
//		logger.error(String.valueOf(boardVO.getOut_parm()));
		if (boardVO.getOut_parm() != 200)
			throw new Exception("dbError");

		// boardDAO.insertBoard2(boardVO);
		// boardDAO.insertBoard3(boardVO);

	}

	private String fileUpload(MultipartFile[] files) throws Exception {
		String fileGroudId = UUID.randomUUID().toString();
		int realFile = 0;
		ArrayList<Thread> threads = new ArrayList<>();
		for (MultipartFile uploadFile : files) {
			if (!uploadFile.isEmpty()) {
				String originalName = uploadFile.getOriginalFilename();
				String ext = FilenameUtils.getExtension(originalName);
				String saveName = UUID.randomUUID().toString() + "." + ext;
				String fileSize = Long.toString(Math.round((double) uploadFile.getSize() / 1024)) + "KB";
				System.out.println(originalName + "***********************************");
				boardDAO.insertFile(new FilesVO(fileGroudId, saveName, originalName, fileSize));

				Path path = Paths.get(directory, saveName);
				if (uploadFile.getSize() < (1024 * 1024 * 10)) {
					Files.write(path, uploadFile.getBytes());
				} else {
					UploadThread ut = new UploadThread(path, uploadFile);
					ut.start();
					threads.add(ut);
				}
				// Thread.sleep(10);
				realFile++;
			}
		}
		for (Thread t : threads) {
			try {
				t.join(); // t 쓰레드가 종료할 때까지 기다린다.
			} catch (Exception e) {
			}
		}
		if (realFile > 0)
			return fileGroudId;
		else
			return "";
	}

	@Override
	public BoardVO viewBoard(BoardVO boardVO) throws Exception {
		BoardVO boardView;
		try {
			if(boardDAO.hitCheck(boardVO) >= 24 * 60 * 60) {
				boardDAO.hitBoard(boardVO);
			}
			boardView = boardDAO.viewBoard(boardVO);
			boardView.setBoardContents(boardView.getBoardContents().replace("\n", "<br>"));
		} catch (Exception e) {
			throw new Exception("viewError");
		}
		return boardView;
	}

	@Override
	public List<FilesVO> viewFileList(String fileGroudId) throws Exception {
		// TODO Auto-generated method stub
		return boardDAO.viewFileList(fileGroudId);
	}

	// 파일 다운로드
	@Override
	public ResponseEntity<byte[]> download(HttpServletRequest request) throws Exception {
		String fileName = request.getParameter("fileName");
		String saveName = request.getParameter("saveName");
		String filePath = directory + fileName;
		try {
			Path file = Paths.get(filePath);
			byte[] data = Files.readAllBytes(file);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			headers.setContentDispositionFormData("attachment", saveName);
			headers.setContentLength(data.length);
			return new ResponseEntity<>(data, headers, HttpStatus.OK);
		} catch (IOException ex) {
//			Path file = Paths.get(directory + "ci.png");
//			byte[] data = Files.readAllBytes(file);
//			HttpHeaders headers = new HttpHeaders();
//			headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//			headers.setContentDispositionFormData("attachment", "error.png");
//			headers.setContentLength(data.length);
//			return new ResponseEntity<>(data, headers, HttpStatus.OK);
			throw new Exception("fileError");
		}

	}

	@Override
	public void delBoard(BoardVO boardVO) throws Exception {
		BoardVO boardView = boardDAO.viewBoard(boardVO);
		boardDAO.delBoard(boardVO);
		if (boardView.getFileGroudId() != null) {
			List<FilesVO> fileList = boardDAO.viewFileList(boardView.getFileGroudId());
			boardDAO.delFile(boardView.getFileGroudId());
			for (FilesVO file : fileList) {
				// System.out.println(file.getSaveName());
				delFile(file.getSaveName());
			}
		}

	}

	private void delFile(String fileName) throws Exception {
		try {
			String filePath = directory + fileName;
			File file = new File(filePath);
			if (file.delete()) {
				System.out.println("파일 삭제성공!");
			}
		} catch (Exception e) {
			throw new Exception("delFile");
		}

	}

	@Override
	public void likeBoard(BoardVO boardVO) throws Exception {
		boardDAO.dellikeBoard(boardVO);
		if(boardVO.getLikeState() != 0) {
			boardDAO.insertlikeBoard(boardVO);
		}
	}

}
