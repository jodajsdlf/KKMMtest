package egov.board.service.impl;

import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.web.multipart.MultipartFile;

public class UploadThread extends Thread {
	
	private Path path;
	private MultipartFile uploadFile;
	
	UploadThread(Path path, MultipartFile uploadFile){
		this.path = path;
		this.uploadFile = uploadFile;
	}
	
	public void run() {
		try {
			Files.write(path, uploadFile.getBytes());
			System.out.println(">>>>>>>>>>>>>>>UploadThread>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
		}catch (Exception e) {
			System.out.println("UploadThread-Error");
		}
	}

}
