package egov.board.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.mapper.Mapper;

import egov.board.model.BoardVO;
import egov.board.model.FilesVO;
import egov.cmm.page.Search;

@Mapper
public interface BoardMapper {

	List<BoardVO> selectBoardList(Search sch) throws Exception;
	int selectBoardListTotCnt() throws Exception;
	void insertBoard(BoardVO boardVO) throws Exception;
	int insertBoard2(BoardVO boardVO) throws Exception;
	int insertBoard3(BoardVO boardVO) throws Exception;
	BoardVO viewBoard(BoardVO boardVO) throws Exception;
	void insertFile(FilesVO filesVO) throws Exception;
	List<FilesVO> viewFileList(String fileGroudId) throws Exception;
	int delBoard(BoardVO boardVO) throws Exception;
	int delFile(String fileGroudId) throws Exception;
	void hitBoard(BoardVO boardVO) throws Exception;
	int hitCheck(BoardVO boardVO)throws Exception;
	void dellikeBoard(BoardVO boardVO)throws Exception;
	void insertlikeBoard(BoardVO boardVO)throws Exception;
}
