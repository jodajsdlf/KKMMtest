package egov.board.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;

import egov.board.model.BoardVO;
import egov.board.model.FilesVO;
import egov.cmm.page.Search;

public interface BoardService {

		List<BoardVO> selectBoardList(Search sch) throws Exception;
		int selectBoardListTotCnt() throws Exception;
		void insertBoard(BoardVO boardVO) throws Exception;
		BoardVO viewBoard(BoardVO boardVO) throws Exception;
		List<FilesVO> viewFileList(String fileGroudId) throws Exception;
		ResponseEntity<byte[]> download(HttpServletRequest request) throws Exception;
		void delBoard(BoardVO boardVO)throws Exception;
		void likeBoard(BoardVO boardVO)throws Exception;
}
