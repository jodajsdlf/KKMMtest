(function ($) {
    var fileUploadCount = 0;

    $.fn.fileUpload = function () {
        return this.each(function () {
            var fileUploadDiv = $(this);
            var fileUploadId = `fileUpload-${++fileUploadCount}`;

            // Creates HTML content for the file upload area.
            var fileDivContent = `

                    <input type="file" id="${fileUploadId}" name="files" multiple  />

            `;

            fileUploadDiv.html(fileDivContent).addClass("file-container");

            var table = null;
            var tableBody = null;
            // Creates a table containing file information.
            function createTable() {
                table = $(`
                    <table border="1">
                        <thead>
                            <tr>
                                <th>번호</th>
                                <th style="width: 30%;">파일이름</th>
                                <th>미리보기</th>
                                <th style="width: 20%;">용량</th>
                                <th>타입</th>
                                <th>삭제</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                `);

                tableBody = table.find("tbody");
                fileUploadDiv.append(table);
            }

            // Adds the information of uploaded files to table.
            function handleFiles(files) {
                if (!table) {
                    createTable();
                }

                tableBody.empty();
                if (files.length > 0) {
                    $.each(files, function (index, file) {
                        var fileName = file.name;
                        var fileSize = (file.size / 1024).toFixed(2) + " KB";
                        var fileType = file.type;
                        var preview = fileType.startsWith("image")
                            ? `<img src="${URL.createObjectURL(file)}" alt="${fileName}" height="30">`
                            : `<i class="material-icons-outlined">미리보기 없음</i>`;

                        tableBody.append(`
                            <tr>
                                <td>${index + 1}</td>
                                <td style="width: 30%;">${fileName}</td>
                                <td>${preview}</td>
                                <td style="width: 20%;">${fileSize}</td>
                                <td>${fileType}</td>
                                <td><a class="btn btn-danger btn-sm btn-icon waves-effect waves-themed deleteBtn">X</a></td>
                            </tr>
                        `);
                    });

                    tableBody.find(".deleteBtn").click(function () {
                        $(this).closest("tr").remove();

                        if (tableBody.find("tr").length === 0) {
                            tableBody.append('<tr><td colspan="6" class="no-file">No files selected!</td></tr>');
                        }
                    });
                }
            }

            fileUploadDiv.find(`#${fileUploadId}`).change(function () {
                handleFiles(this.files);
            });
        });
    };
})(jQuery);
