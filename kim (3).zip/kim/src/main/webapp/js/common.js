
$(function() {

	

});

function loding() {
	$("body").append('<div class="loader"></div>');
	$("body").children().not(".loader").hide(); // body 내용 중 .loader를 제외한 모든 요소 숨기기
	$(".loader").show(); // 로딩 스피너 보이기
}

function errorPop(titles, texts, urls) {
	Swal.fire({
		title: titles,
		text: texts,
		icon: "error",
		allowOutsideClick: false
	}).then(function(result) {
		if (result.value) {
			window.location.href = urls;
		}
	});
}

